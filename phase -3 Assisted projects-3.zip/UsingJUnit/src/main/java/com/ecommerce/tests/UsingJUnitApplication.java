package com.ecommerce.tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsingJUnitApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsingJUnitApplication.class, args);
	}

}
